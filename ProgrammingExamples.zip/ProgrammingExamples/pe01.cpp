#include <iostream>
#include <ctime>
using namespace std;


int main() {

	int total = time(0);
	cout << "Seconds since 1/1/1970:  " << total << endl;


	int minutes = total / 60;
	int seconds = total % 60;
	int hours = minutes / 60;
	int days = hours / 24;
	hours = hours % 24;
	minutes = minutes % 60;

	cout << "days    :  " << days << endl;
	cout << "Hours   :  " << hours << endl;
	cout << "Minutes :  " << minutes << endl;
	cout << "Seconds :  " << seconds << endl;

	
}