#include <iostream>
using namespace std;

int main() {
	double distance, weight;  // input
	const double COST_PER_LB  = 2.5;
	const double MILEAGE_BASIS = 200;
	double cost; // output

	cout << "Please enter distance to ship (miles):  ";
	cin  >> distance;
	cout << "Please enter weight of item (pounds):   ";
	cin  >> weight;

	double cost200 = weight * COST_PER_LB;
	cost = cost200 * distance / MILEAGE_BASIS;
	
	cout << "Distance to ship:  " << distance << " miles" << endl;
	cout << "Weight of item:    " << weight << "lbs" << endl;
	cout << "Cost to ship:     $" << cost << endl;
}