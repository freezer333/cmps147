#include <iostream>
using namespace std;

int main() {
	double pretax, rate, finalPrice;
	
	cout << "Enter pretax:  $";
	cin  >> pretax;

	cout << "Enter sales tax rate (7 for 7%):  ";
	cin  >> rate;

	//rate = rate / 100;
	double tax = pretax * rate / 100;
	finalPrice = pretax + tax;

	cout << "Pre-tax amount:  $" << pretax << endl;
	cout << "Sales tax:        " << rate << "%" <<endl;
	cout << "Final Price:     $" << finalPrice << endl;

}