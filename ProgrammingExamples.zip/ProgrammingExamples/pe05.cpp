#include <iostream>
using namespace std;

int computeCoin(int coinValue, int & amount);

int main() {
	double input;
	int amount;

	cout << "Please enter amount:  $";
	cin  >> input;

	amount = static_cast<int>(input * 100 + 0.5);
	cout << amount << endl;

	int quarters = computeCoin(25, amount);
	int dimes = computeCoin(10, amount);
	int nickels = computeCoin(5, amount);
	
	cout << "Quarters:   " << quarters << endl;
	cout << "Dimes:      " << dimes << endl;
	cout << "Nickels:    " << nickels << endl;
	cout << "Pennies:    " << amount << endl;
}

int computeCoin(int coinValue, int & w) {
	int numCoins = w / coinValue;
	w %= coinValue;
	return numCoins;
	
}