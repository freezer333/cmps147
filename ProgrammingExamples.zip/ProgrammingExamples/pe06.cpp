#include <iostream>
#include <cmath>
using namespace std;

int main() {
	// Step 1
	double distance;
	const double a = 9.8;
	double time;

	// step 2
	cout << "Please enter distance to fall (meters):  ";
	cin  >> distance;

	// step 3
	double tmp = 2 * distance / a;
	time = sqrt(tmp);

	// step 4
	cout << "Distance " << distance << " meters" << endl;
	cout << "Acceleration:  " << a << " m/sec2" << endl;
	cout << "Time " << time << " sec" << endl;






}