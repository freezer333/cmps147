#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;

int main() {
	double principal;
	double rate;
	int times;
	double amount;

	cout << "Please enter opening balance:  $:  " ;
	cin  >> principal;

	cout << "Please enter yearly interest rate (ex. 1 for 1%):  ";
	cin  >> rate;
	rate /= 100;  // rate = rate / 100;

	cout << "Enter number of time compounded (ex 12 for monthly):  ";
	cin  >> times;

	double tmp = 1 + rate / times;
	amount = principal * pow(tmp, times);
	
	cout << left;
	cout << fixed;
	cout << setprecision(2);
	cout << setw(29) << "Principal:" << "$" << principal << endl;
	cout << setprecision(1);
	cout << setw(30) << "Interest rate:  " << rate * 100  << "%" <<endl;
	cout << setw(30) << "Times compounded annually:  " << times << endl;
	cout << setprecision(2);
	cout << setw(29) << "Amount after one year:" << "$" << amount << endl;


}