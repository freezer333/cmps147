#include <iostream>
using namespace std;


int main() {
	int x, y;

	cout << "Please enter two numbers:  ";
	cin  >> x >> y;

	if ( x == y ) {
		cout << "They are equal!" << endl;
	}
	
	if ( x < y ) {
		cout << y << " is larger"  << endl;
	}
	
	if ( x > y ) {
		cout << x << " is larger" << endl;
	}
	cout << "All done..." << endl;
}