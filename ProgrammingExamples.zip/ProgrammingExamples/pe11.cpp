#include <iostream>
using namespace std;


int main() {

	double a, b, c;
	cout << "Enter a b c coefficients:  ";
	cin  >> a >> b >> c;

	double determinant = b*b - 4 * a * c;

	if ( determinant >= 0 ) {
		double den = 2 * a;
		double num1 = -b + sqrt(determinant);
		double num2 = -b - sqrt(determinant);
		double root1 = num1 / den;
		double root2 = num2 / den;

		cout << "Root1:  " << root1 << endl;
		cout << "Root2:  " << root2 << endl;
	}
	if ( determinant < 0 ) {
		cout << "no roots!" << endl;
	}

}