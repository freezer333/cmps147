#include <iostream>
using namespace std;


int main() {

	int grade;
	cout << "Enter a grade (0-100):  ";
	cin  >> grade;

	cout << "Your letter grade is ";
	if ( grade >= 90 ) {
		cout << "A" << endl;
	}
	else if ( grade >= 80 ) {
		cout << "B" << endl;
	}
	else if ( grade >= 70 )  {
		cout << "C" << endl;
	}
	else if ( grade >= 60 ) {
		cout << "D" << endl;
	}
	else {
		cout << "F" << endl;
	}
	cout << "!" << endl;


}