#include <iostream>
using namespace std;

int main() {

	double salary;
	double yrsWorked;

	cout << "Please enter yearly salary:  $";
	cin  >> salary;

	cout << "Enter number of years at current job:  ";
	cin  >> yrsWorked;
	/*
	if ( salary >= 60000 ) {
		cout << "You are approved" << endl;
	}
	else {
		if ( salary >= 35000 && yrsWorked >= 5 ) {
			cout << "You are approved" << endl;
		}
		else {
			cout << "You are denied" << endl;
		}
	}*/
	if ( salary >= 60000 || salary >= 35000 && yrsWorked >= 5) {
		cout << "You are approved" << endl;
	}
	else {
		cout << "You are denied" << endl;
	}
	


}