#include <iostream>
using namespace std;


int my_pow(int base, int exp) {
	int product = 1;
	for ( int i = 0; i < exp; i++ ) {
		product *= base;
	}
	return product;
}

int main() {
	int x, y;

	cout << "Enter base and exponent:  ";
	cin  >> x >> y;

	int value = my_pow(x, y);
	cout << x << "^" << y << " = " << value << endl;


}