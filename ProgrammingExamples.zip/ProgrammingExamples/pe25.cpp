#include <iostream>
using namespace std;

char getLetterGrade(double grade) {
	char letter;
	if ( grade >= 90 ) {
		letter = 'A';
	}
	else if ( grade >= 80 ) {
		letter = 'B';
	}
	else if ( grade >= 70 ) {
		letter = 'C';
	}
	else if ( grade >= 60 ) {
		letter = 'D';
	}
	else {
		letter = 'F';
	}
	return letter;
}

void printLetterGrade(double grade) {
	cout << "Letter grade:  " << getLetterGrade(grade) << endl;
}

int main() {
	double sum = 0;
	int count = 0;
	double input;
	char let;
	do {
		cout << "Please enter grade (0-100): ";
		cin  >> input;

		if ( input >= 0 && input <= 100 ) {
			sum += input;
			count++;
			printLetterGrade(input);
		}
	} while ( input != -1);

	double average = sum / count;
	let = getLetterGrade(average);
	cout << "Average is " << average << ", which is a " << let << endl;
}