#include <iostream>
using namespace std;

double estimateEx(double x, int N);
double computeTerm(double x, int termNumber);
double factorial(int n);

int main() {
	double x;
	int n;

	cout << "Enter x:  ";
	cin  >> x;
	cout << "How many terms?  "  ;
	cin  >> n;

	double ex = estimateEx(x, n);
	// e^5 = 148.413159102577
	cout << "e^x = " << ex << endl;
}


double estimateEx(double x, int N) {
	double value = 0;
	for ( int i = 0; i <= N; i++ ){
		double term = computeTerm(x, i);
		value += term;
		cout << "Term " << i << " -> " << term << endl;
	}
	return value;
}

double computeTerm(double x, int termNumber) {
	double num = pow(x, termNumber);
	double den = factorial(termNumber);
	return num / den;
}

double factorial(int n) {
	//n = 5.. 2 * 3 * 4 * 5
	double value = 1;
	for ( int i = 2; i <= n; i++ ) {
		value *= i;
	}
	return value;
}