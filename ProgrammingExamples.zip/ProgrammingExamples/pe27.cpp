#include <iostream>
using namespace std;

int computeCoin(int & amount, int denomination);

int main() {
	double input;
	int amount;
	int q, d, n;

	cout << "Enter amount  $:  ";
	cin  >> input;

	amount = static_cast<int>(input * 100 + 0.05);
	
	q = computeCoin(amount, 25);
	d = computeCoin(amount, 10);
	n = computeCoin(amount, 5);
	
	cout << "Quarters:   " << q << endl;
	cout << "Dimes:      " << d << endl;
	cout << "Nickels:    " << n << endl;
	cout << "Pennies:    " << amount << endl;
}

int computeCoin(int & x, int denomination){
	int value = x / denomination;
	x %= denomination;
	return value;
}