#include <iostream>
using namespace std;


int main() {
	const int SIZE = 15;
	int x[SIZE];
	int count = 0;
	int input;

	do {
		cout << "enter a number (-1 to stop):  ";
		cin  >> input;
		if ( input != -1 ) {
			x[count++] = input;
		}
	} while ( input != -1 && count < SIZE);

	for (int i = 0; i < count; i++ ) {
		cout << x[i] << endl;
	}

	do {
		cout << "Enter a number to search for:   ";
		cin  >> input;
		if ( input != -1 ) {
			int numFound = 0;
			for ( int i = 0; i < count; i++ ) {
				if ( x[i] == input ) {
					numFound++;
				}
			}
			if ( numFound > 0 ) {
				cout << "exists " << numFound << " times"  << endl;
			}
			else {
				cout << "not there" << endl;
			}
		}
	} while ( input != -1 ) ;



}
