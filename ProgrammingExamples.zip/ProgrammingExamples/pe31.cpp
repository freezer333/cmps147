#include <iostream>
using namespace std;

int getArray(int a[], int maxSize);
void printArray(int x[], int count);
bool equal(int a[], int countA, int b[], int countB);
bool equivelant(int a[], int countA, int b[], int countB);

int main() {
	const int SIZE = 15;
	int a1[SIZE];
	int a2[SIZE];

	// Get two lists from user...
	cout << "Enter first list:  " << endl;
	int count1 = getArray(a1, SIZE);
	cout << "Enter second list:  " << endl;
	int count2 = getArray(a2, SIZE);

	printArray(a1, count1);
	cout << "--------" << endl;
	printArray(a2, count2);

	if ( equal(a1, count1, a2, count2) ) {
		cout << "Lists are equal" << endl;
	}
	else if ( equivelant(a1, count2, a2, count2) ) {
		cout << "Lists are equivelant" << endl;
	}
	else {
		cout << "Lists are not related" << endl;
	}
}



bool equal(int a[], int countA, int b[], int countB) {
	if ( countA != countB ) return false;
	
	for ( int i = 0; i < countA; i++ ) {
		if ( a[i] != b[i] ) {
			return false;
		}
	}

	return true;
}

int count(int x[], int key, int count) {
	int times = 0 ;
	for ( int i = 0; i < count; i++ ) {
		if ( x[i] == key ) {
			times++;
		}
	}
	return times;
}

bool equivelant(int a[], int countA, int b[], int countB) {
	if ( countA != countB ) return false;

	for ( int i = 0; i < countA; i++ ) {
		int c_a = count(a, a[i], countA);
		int c_b = count(b, a[i], countB);
		if ( c_a != c_b ) {
			return false;
		}
	}
	return true;
}



int getArray(int a[], int maxSize) {
	int input;
	int count = 0;
	do {
		cout << "Please enter number (-1 to stop):  ";
		cin  >> input;
		if ( input != -1 ) {
			a[count++] = input;
		}
	} while  (input != -1 && count < maxSize);

	return count;
}

void printArray(int x[], int count) {
	for ( int i = 0; i < count; i++ ) {
		cout << x[i] << endl;
	}
}
