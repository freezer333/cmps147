#include <iostream>
using namespace std;


int findInsertIndex(double data [], int size, double value) {
    for (int i = 0; i < size; i++ ) {
        if ( value < data[i] ) return i;
    }
    return size;
}

void insertHere(double data[], int & count, double value, int index) {

    for ( int i = count; i > index; i-- ) {
        data[i] = data[i-1];
    }
    data[index] = value;
    count++;
}


int main() {
    double values[20];
    int count = 0;
    double input;
    do {
        cout << "Enter a number (-1 to stop):  ";
        cin  >> input;
        if ( input != -1) {
            int p = findInsertIndex(values, count, input);
            insertHere(values, count, input, p);
        }
    } while ( input != -1 && count < 20);

    for ( int i = 0; i < count; i++ ) {
        cout << values[i] << endl;
    }
}
