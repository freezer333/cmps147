#include <iostream>
#include <cstring>
using namespace std;


int main() {
	char a[50];
	char b[50];

	cout << "Please enter string 1:  ";
	cin.getline(a, 50);

	cout << "Please enter string 2:  ";
	cin.getline(b, 50);

	cout << "String 1:  " << a << endl;
	cout << "String 2:  " << b << endl;

	if ( strcmp(a, b) == 0 ) {
		cout << "These strings are equal!" << endl;
	}
	else {
		cout << "These strings are different" << endl;
	}

}