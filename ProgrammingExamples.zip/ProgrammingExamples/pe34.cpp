#include <iostream>
#include <cstring>
using namespace std;


bool isPalendrome(char s[] ) {
	int i = 0;
	int j = strlen(s) - 1;
	while ( i < j ) {
		if ( s[i] != s[j] ) {
			return false;
		}
		i++;
		j--;
	}
	return true;
}


void cleanup(char src[], char dest[]) {
	int src_index = 0;
	int dest_index = 0;
	while ( src[src_index] != '\0' ) {
		if ( !isspace(src[src_index]) ) {
			dest[dest_index] = tolower(src[src_index]);
			dest_index++;
		}
		src_index++;
	}
	dest[dest_index] = '\0';
	cout << src << " converted to " << dest << endl;
}

int main() {
	char s[50];
	char clean[50];
	
	cout << "Please enter string:  ";
	cin.getline(s, 50);

	cleanup(s, clean);
	
	if ( isPalendrome(clean) ) {
		cout << "Palendrome!" << endl;
	}
	else {
		cout << "Nope.." << endl;
	}

}