#include <iostream>
using namespace std;


int main() {
	double radius;
	double area;
	const double PI = 3.14159;

	// gather data from user
	cout << "Please enter a radius:  ";
	cin  >> radius;

	// calculate results
	area = PI * radius * radius;

	// output results
	cout << "Radius:   "  << radius << endl;
	cout << "Area  :   "  << area << endl;


}