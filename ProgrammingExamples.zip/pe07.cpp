#include <iostream>
#include <cmath>

using namespace std;


int main() {
	double a;
	const double PI = 3.14159;
	double circle, triangle, square, pentagon, hexagon;

	cout << "Enter a dimension:  ";
	cin  >> a;

	double sqrt3 = sqrt(3);
	double a_squared = a * a;

	circle = PI * a_squared; // PI * pow(a, 2)
	triangle = sqrt3 / 4 * a_squared;
	square = a_squared;
	double tmp = 5 * ( 5 + 2 * sqrt(5));
	pentagon = 1.0 / 4 * sqrt(tmp) * a_squared;
	hexagon = 3 * sqrt3 / 2 * a_squared;

	cout << "Area of circle:  " << circle << endl;
	cout << "Area of triangle:  " << triangle << endl;
	cout << "Area of square:  " << square << endl;
	cout << "Area of pentagon:  " << pentagon << endl;
	cout << "Area of hexagon:  " << hexagon << endl;
}