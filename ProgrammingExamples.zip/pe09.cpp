#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;

int main() {

	double principal;
	double yearlyRate;
	int timesCompounded;
	double amount;

	cout << "Enter openning balance:  $";
	cin  >> principal;
	cout << "Enter yearly interest rate (APR) (ex. 1 for 1%):  ";
	cin  >> yearlyRate;
	cout << "Enter number of times interest is applied per year (ex. 12 for monthly):  ";
	cin  >> timesCompounded;
	double rate = yearlyRate / 100;
	double base = 1 + rate / timesCompounded;
	amount = principal * pow (base, timesCompounded);

	cout << left;
	cout << fixed;
	cout << setprecision(2);
	cout << setw(25) << "Principal:  " << "$" <<  principal << endl;
	cout << setprecision(1);
	cout << setw(25) << "Yearly Rate:  " << yearlyRate << "%" << endl;
	cout << setw(25) << "Times compounded:  " << timesCompounded << endl;
	cout << setprecision(2);
	cout << setw(25) << "Amount at end of year:  "<< "$" << amount << endl;

}