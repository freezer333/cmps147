#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int main() {
	srand(time(0));
	// 10 and 50
	int x = rand() % 40 + 10;
	int y = rand() % 40 + 10;
	int answer = x + y;
	cout << "  " << x << endl;
	cout << "+ " << endl;
	cout << "  " << y << endl;
	cout << "------------------" << endl;

	int input;
	cin >> input;

	if ( input == answer ) {
		cout << "Correct!" << endl;
	}
	if ( input != answer ) {
		cout << "Sorry, the answer is " << answer << endl;
	}
	


}