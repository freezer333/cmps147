#include <iostream>
#include <cctype>
using namespace std;

char getUnitFromUser();
double getTempfromUser();
double toF(double c);
double toC(double f);
void outputResults(double c, double f);

int main() {
	char choice = getUnitFromUser();
	double input = getTempfromUser();
	double c, f;
	if ( choice == 'C' ) {
		c = input;
		f = toF(c);
	}
	else {
		f = input;
		c = toC(f);
	}
	outputResults(c, f);
}

char getUnitFromUser() {
	char input;
	do {
		cout << "Please enter (C) celsius or (F) fahrenhiegt:  ";
		cin  >> input;
		input = toupper(input);
	} while ( input != 'C' && input != 'F');
	
	return input;
}
double getTempfromUser() {
	double input;
	cout << "Please enter a temperature:  ";
	cin  >> input;
	return input;
}
double toF(double c) {
	return c * 9.0 / 5 + 32;
}
double toC(double f) {
	return 5.0 / 9 * (f - 32);
}
void outputResults(double c, double f) {
	cout << "Degrees C:  " << c << endl;
	cout << "Degrees F:  " << f << endl;
}
