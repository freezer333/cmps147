#include <iostream>
using namespace std;


int main() {
	const int SIZE = 5;
	int x[SIZE];
	int index;

	for ( int i = 0; i < SIZE; i++ ) {
		cout << "Enter a number:  ";
		cin  >> x[i];
	}

	cout << "--- Your numbers ----" << endl;
	for ( int i = 0; i < SIZE; i++ ) {
		cout << i << " => " << x[i] << endl;
	}

	cout << "---------------------" << endl;
	do {
		cout << "Enter an index (-1 to stop):  ";
		cin  >> index;
		// larger than greatest index, less than -1)
		if ( index < -1 || index >= SIZE) {
			cout << "That index is out of the bounds of the array" << endl;
		}
		else if ( index != -1 ) {
			cout << x[index] << endl;
		}
	} while ( index != -1 );



}